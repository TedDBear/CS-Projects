#include <iostream>
#include <forward_list>
#include <stack>
#include <queue>

using namespace std;

void readList(forward_list<string>);
 
int main()
{
	forward_list <string> words{"Hello ", "name. ", "How ", "are ", "you? "};
	queue <int> numbers;
	stack <int> moreNumbers;

	cout << "Forward List with words" << endl;
	cout << "--------------------------------" << endl;
	cout << "\nThe current list: " << endl;
	readList(words);

	words.remove("name. ");

	cout << "\nAfter removing \"name. \" from the list: " << endl;
	readList(words);

	words.insert_after(words.begin(), "Seth! ");

	cout << "\nAfter using the \"insert_after\" function to insert \"Seth! \": " << endl;
	readList(words);

	words.reverse();

	cout << "\nAfter reversing the order of the list: " << endl;
	readList(words);

	numbers.push(1);
	numbers.push(2);
	numbers.push(3);
	numbers.push(4);

	int first = numbers.front();
	int last = numbers.back();

	cout << "\nNumbers Queue" << endl;
	cout << "------------------------------" << endl;

	cout << "\nThe first number in the numbers queue: " << first << endl;
	cout << "\nThe last number in the numbers queue: " << last << endl;

	numbers.pop();
	first = numbers.front();

	cout << "\nThe first number in the numbers queue after popping: " << first << endl;
	cout << "\nThe size of the numbers queue: " << numbers.size() << endl;

	moreNumbers.push(5);
	moreNumbers.push(6);
	moreNumbers.push(7);
	moreNumbers.push(8);

	int top = moreNumbers.top();

	cout << "\nMoreNumbers Stack" << endl;
	cout << "------------------------------" << endl;

	cout << "\nThe top number in the moreNumbers Stack: " << top << endl;
	

	moreNumbers.pop();
	top = moreNumbers.top();

	cout << "\nThe top number in the moreNumbers Stack after popping: " << top << endl;
	cout << "\nThe size of the moreNumbers Stack: " << moreNumbers.size() << endl;

	
	return 0;
}

void readList(forward_list<string> words)
{
	for (auto sentence : words)
	{
		cout << sentence;
	}
	cout << endl;
}
