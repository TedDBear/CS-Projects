// Stephen Craig
// COSC 1436 Pa2 - Digit Extractor
// Created 8/30/2021
// program computes and outputs the individual digits of a number up to 3 digits long
#include <iostream>
using namespace std;

const int QUIT = 0;		// value to end the program

int main()
{
	int threeNumberDigit;	// a number up to three digits
	cout << "Digit Extractor\n\n";
	cout << "This program will Extract up to 3 Digits beginning with the 100's place value.\nNumbers entered may be positive or negative.";

	cout << "\n\nEnter a 3-digit number (or enter 0 to exit the program): ";
	cin >> threeNumberDigit;
	while (threeNumberDigit != QUIT)
	{ 
		int hundred = threeNumberDigit / 100 % 10;	// The left most digit of a three digit number
		int ten = threeNumberDigit / 10 % 10;	// The middle digit of a three digit number
		int one = threeNumberDigit % 10;	// The right most digit of a three digit number

	  cout << "The digits in the number " << threeNumberDigit << " are " 
		   << hundred << ", " 
		   << ten << ", " 
		   << one << ", " 
		   << endl;
	  	
	  cout << "\nEnter another 3-digit number (or enter 0 to exit the program): ";
	  cin >> threeNumberDigit;
	}
	cout << "\nThank You for using The Digit Extractor.  Goodbye!";// Tells the user that the program ended

	return 0;
}
