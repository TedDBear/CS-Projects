// Stephen Craig
// COSC 1436 PA1 - Trip Estimator
// Created on 8/25/2021
// trip estimator 
// program computes and outputs the amount of gas needed, and the cost of a trip
#include <iostream>
#include <iomanip>
using namespace std;

const int SENTINEL = 0;		// value to end the program

int main()
{
	int tripDistance;		// distance of the trip in miles
	double milesPerGal;		// miles per gallon estimate of the car 
	double avgGasCost;		// average cost of a gallon of gas in US dollars
	double gasNeeded;		// total number of gallons of gas needed
	double costOfTrip;		// estimated cost of the trip in US dollars

	cout << "Trip Estimator\n\n";
	cout << "What is the trip distance? 0r press 0 to end program. ";
	cin >> tripDistance;	
	while (tripDistance != SENTINEL)	// continual loop until "SENTINEL" is entered
	{

		cout << "\nHow many MPG does the car go? ";
		cin >> milesPerGal;

		cout << "\nHow much does a gallon of gas cost in your area? $";
		cin >> avgGasCost;

		gasNeeded = tripDistance / milesPerGal;		// trip distance / miles per gallon = the amount of gas needed	
		costOfTrip = gasNeeded * avgGasCost;	// the amount of gas needed x the average gas cost = the cost of the trip

		cout << "\nTrip Distance: " << tripDistance << endl;
		cout << "Miles Per Gallon: " << milesPerGal << endl;
		cout << fixed << setprecision(2) << "Average Gas Cost: $" << avgGasCost << endl;
		cout << fixed << setprecision(1) << "\nThe amount of gas needed: " << gasNeeded << endl;
		cout << fixed << setprecision(2) << "The Cost of the Trip: $" << costOfTrip << endl;

		cout << "\nWhat is the trip distance? Or press 0 to end program. ";
		cin >> tripDistance;
	}
	cout << "\nThank You for using the Trip Estimator\n GOODBYE!";	// Tells user that the program has ended

		return 0;
}
