function width(x, y)
{
let points = [];
points.push(x, y);
for (var d=1; d<=3; d++)
{
points.push(x, y-d);
points.push(x, y+d);
}
return points
}
function plot(x, y)
{
let points = [];
points = points.concat(width(x, y));
points = points.concat(width(x, -1*y));
points = points.concat(width(-1*x, y));
points = points.concat(width(-1*x, -1*y));
return points;
}
function drawEllipse(rx, ry)
{
  // Midpoint Circle Algorithm plotting top quadrant of ellipse
  let vertices = [];
  let points = [];
  let rxsquared = rx * rx;
  let rysquared = ry * ry;
  let tworxsquared = 2 * rxsquared;
  let tworysquared = 2 * rysquared;

  let x0 = 0;
  let y0 = ry;
  points = plot (x0, y0);
  for (let i=0; i<points.length; i++)
  {
    vertices.push(points[i]);
  }
  let p0 = rysquared - rxsquared * ry + (0.25 * rxsquared);

  let xk = x0;
  let yk = y0;
  let pk = p0;

  while (tworysquared * xk <= tworxsquared * yk)
  {
    if (pk < 0)
    {
      xk = xk + 1;
      points = plot (xk, yk);
      for (let i=0; i<points.length; i++)
      {
        vertices.push(points[i]);
      }
      pk = pk + (tworysquared * xk) + rysquared;
    }
    else
    {
      xk = xk + 1;
      yk = yk - 1;
      points = plot (xk, yk);
      for (let i=0; i<points.length; i++)
      {
        vertices.push(points[i]);
      }
      pk = pk + (tworysquared * xk) + rysquared - (tworxsquared * yk);
    }
  }

  pk = (rysquared * (xk + 0.5) * (xk + 0.5)) + (rxsquared * (yk -1) * (yk - 1)) - (rxsquared * rysquared)
  while (yk > 0)
  {
    if (pk > 0)
    {
      yk = yk - 1;
      points = plot(xk, yk);
      for (let i=0; i<points.length; i++)
        {
          vertices.push(points[i]);
        }
      pk = pk - (tworxsquared * yk) + rxsquared;
    }
    else
    {
      xk = xk + 1;
      yk = yk - 1;
      points = plot(xk, yk);
      for (let i=0; i<points.length; i++)
        {
          vertices.push(points[i]);
        }
      pk = pk - (tworxsquared * yk) + rxsquared + (tworysquared * xk);
    }

  }
  return vertices;
}


