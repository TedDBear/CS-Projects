//width = 5
function width(x, y)
{
  let points = [];
  points.push(x, y);
  for (var d=1; d<=5; d++)
  {
  points.push(x, y-d);
  points.push(x, y+d);
  }
  return points
}

function plotCircle(x, y)
{
  let points = [];
  points = points.concat(width(x, y));
  points = points.concat(width(x, -1*y));
  points = points.concat(width(-1*x, y));
  points = points.concat(width(-1*x, -1*y));
  points = points.concat(width(y, x));
  points = points.concat(width(-1*y, x));
  points = points.concat(width(y, -1*x));
  points = points.concat(width(-1*y, -1*x));
  return points;
}
function drawCircle(r)
{
  // Midpoint Circle Algorithm plotting top sector of circle
  let vertices = [];
  let points = [];
  let x0 = 0;
  let y0 = r;
  points = plotCircle(x0, y0);
  for (let i=0; i<points.length; i++)
  {
    vertices.push(points[i]);
  }
  let p0 = 1 - r;
  let xk = x0;
  let yk = y0;
  let pk = p0;
  while (xk < yk)
{
  if (pk < 0)
  {
  xk = xk + 1;
  points = plotCircle(xk, yk);
  for (let i=0; i<points.length; i++)
  {
    vertices.push(points[i]);
  }
  pk = pk + (2 * xk) + 1;
  }
  else
  {
    xk = xk + 1;
    yk = yk - 1;
    points = plotCircle(xk, yk);
    for (let i=0; i<points.length; i++)
    {
      vertices.push(points[i]);
    }
    pk = pk + (2 * xk) + 1 - (2 * yk);
  }
}
  return vertices;
}


