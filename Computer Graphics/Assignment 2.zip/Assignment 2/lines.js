function vertical(x, y, width) {
    let points = [];

    points.push(x,y);

    for(let i = 1; i < (width/2); i++)
    {
        points.push(x, y + i);
        points.push(x, y - i);
    }

    return points;
}


function drawLine(x0, y0, xend, yend) {
    let vertices = [];
    let points = [];
    let slope = 0;
    let width = 20; //Defines the width of the line.
    y2y1 = yend - y0;
    x2x1 = xend - x0;

    //Prevents the function from divding by zero, and it makes lines that go up and down.
    if(x2x1 == 0)
    {
    for(let i = y0; i < yend; i++)
    {
        points.push(x0, i);

        //Gives width for this line since vertical function does not affect a up and down line
        for(let j = 1; j < 3; j++)
        {
            points.push(x0 + j, i);
            points.push(x0 - j, i);
        }  
    }
    for (let k=0; k<points.length; k++)
    {
        vertices.push(points[k]);
    }
    return vertices;
}
    //Calculates the slope.
    else{
        slope = y2y1/x2x1;
    }
    //creates a straight line.
    if (slope == 0){
        for(let i = x0; i < xend; i++)
        {
            points = vertical(i, y0, 6);
            for (let j=0; j<points.length; j++)
            {
                vertices.push(points[j]);
            }
        }
        return vertices;
    }
    //Bresenham's algorithm. Assummes the slope is a positive integer less than or equal to 1
    else if(slope > 0 && slope <= 1){
        let dx = xend - x0;
        let dy = yend - y0;
        let twodx = 2 * dx;
        let twody = 2 * dy;
        let twodydx = twody - twodx;
        let pk = twody - dx;
        let xk = x0;
        let yk = y0;

        points = vertical(x0, y0, width);
        for (let i=0; i<points.length; i++)
        {
            vertices.push(points[i]);
        }

        points = vertical(xend, yend, width);
        for (let i=0; i<points.length; i++)
        {
            vertices.push(points[i]);
        }

        while(xk < xend)
        {
        if(pk < 0) {
            points = vertical(xk + 1, yk, width);
            for (let i=0; i<points.length; i++)
            {
                vertices.push(points[i]);
            }
            pk = pk + twody;
        }

        else {
            points = vertical(xk, yk + 1, width);
            for (let i=0; i<points.length; i++)
            {
                vertices.push(points[i]);
            }
            pk = pk + twodydx;
            yk = yk + 1;
        }
        xk = xk + 1;
        }
    }
    //If the slope is negative and less than -1, keep subtracting yk instead of adding it when pk < 0
    else if(slope < 0 && slope >= -1){
        let dx = Math.abs(xend - x0);
        let dy = Math.abs(yend - y0);
        let twodx = 2 * dx;
        let twody = 2 * dy;
        let twodydx = twody - twodx;
        let pk = twody - dx;
        let xk = x0;
        let yk = y0;

        if(x0 > xend){
            xk = xend;
            yk = yend;
            xend = x0;
            yend = y0;
        }

        let ystep = (y0 >= yend) ? -1 : 1;

        points = vertical(xk, yk, width);
        for (let i=0; i<points.length; i++)
        {
            vertices.push(points[i]);
        }

        points = vertical(xend, yend, width);
        for (let i=0; i<points.length; i++)
        {
            vertices.push(points[i]);
        }

        while(xk < xend)
        {
        if(pk < 0) {
            points = vertical(xk + 1, yk, width);
            for (let i=0; i<points.length; i++)
            {
                vertices.push(points[i]);
            }
            pk = pk + twody;
        }

        else {
            points = vertical(xk, yk + 1, width);
            for (let i=0; i<points.length; i++)
            {
                vertices.push(points[i]);
            }
            pk = pk + twodydx;
            yk = yk + ystep;
        }
        xk = xk + 1;
        }
    }
    //If the slope is greater than one, reverse the roles of x and y.
    else if(slope > 1 || slope < -1){
        let dx = Math.abs(xend - x0);
        let dy = Math.abs(yend - y0);
        let twodx = 2 * dx;
        let twody = 2 * dy;
        let twodxdy = twodx - twody;
        let pk = twodx - dy;
        let xk = x0;
        let yk = y0;

        let xstep = (x0 > xend) ? -1 : 1;

        points = vertical(x0, y0, width);
        for (let i=0; i<points.length; i++)
        {
            vertices.push(points[i]);
        }

        points = vertical(xend, yend, width);
        for (let i=0; i<points.length; i++)
        {
            vertices.push(points[i]);
        }

        while(yk < yend)
        {
        if(pk < 0) {
            points = vertical(xk, yk + 1, width);
            for (let i=0; i<points.length; i++)
            {
                vertices.push(points[i]);
            }
            pk = pk + twodx;
        }

        else {
            points = vertical(xk + 1, yk, width);
            for (let i=0; i<points.length; i++)
            {
                vertices.push(points[i]);
            }
            pk = pk + twodxdy;
            xk = xk + xstep;
        }
        yk = yk + 1;
        }
    }
return vertices;

}