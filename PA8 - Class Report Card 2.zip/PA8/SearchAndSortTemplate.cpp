template <class AnyType>
void swapV(AnyType& i, AnyType& j)
{
	AnyType temp;	// holds value temporarily

	temp = i;
	i = j;
	j = temp;

}

template <class BaseType>
int minIndex(const BaseType list[], int startIndex, int endIndex)
{
	if (startIndex < 0 || startIndex > endIndex)
		return -1;

	int indexOfMin = startIndex;

	for (int index = startIndex + 1; index < endIndex; index++)
		if (list[index] < list[indexOfMin])
		{
			indexOfMin = index;
			// indexOfMin is the index of the smallest item of 
			// list[startIndex] to list[index]
		}
	return indexOfMin;


}

template <class Type1, class Type2, class Type3, class Type4, class Type5>
void selSort(Type1 list1[], Type2 list2[], Type3 list3[], Type4 list4[], Type5 list5[], const int size)
{
	int indexOfNextSmallest;	// finds the next smallest item in a list

	for (int index = 0; index < size - 1; index++)
	{
		// finds the smallest value and swaps with the value at the current index
			indexOfNextSmallest = minIndex(list1, index, size);	

			swapV(list1[index], list1[indexOfNextSmallest]);
			swapV(list2[index], list2[indexOfNextSmallest]);
			swapV(list3[index], list3[indexOfNextSmallest]);
			swapV(list4[index], list4[indexOfNextSmallest]);
			swapV(list5[index], list5[indexOfNextSmallest]);
	}
 }